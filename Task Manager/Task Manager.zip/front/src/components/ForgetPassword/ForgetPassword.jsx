import React from 'react';

const ForgetPassword = () => {
    return (
        <div>

        </div>
    );
};

export default ForgetPassword;